import java.io.*;

class Student implements Serializable {
    private int studentID;
    private String name;
    private String grade;

    public Student(int studentID, String name, String grade) {
        this.studentID = studentID;
        this.name = name;
        this.grade = grade;
    }

    public int getStudentID() { return studentID; }
    public String getName() { return name; }
    public String getGrade() { return grade; }
}

public class StudentSerializationDemo {
    public static void main(String[] args) {
        Student student = new Student(101, "Alice", "A");

        // Serialize the student object
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("student.ser"))) {
            oos.writeObject(student);
            System.out.println("Student object serialized.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialize the student object
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("student.ser"))) {
            Student deserializedStudent = (Student) ois.readObject();
            System.out.println("Student Details after Deserialization:");
            System.out.println("ID: " + deserializedStudent.getStudentID());
            System.out.println("Name: " + deserializedStudent.getName());
            System.out.println("Grade: " + deserializedStudent.getGrade());
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
