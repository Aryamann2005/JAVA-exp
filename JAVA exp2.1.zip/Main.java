import java.util.ArrayList;
import java.util.Scanner;

public class SumOfIntegersAutoboxing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> integerList = new ArrayList<>();
        System.out.println("Enter integers (type 'done' to finish):");
        while (true) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            try {
                Integer value = Integer.parseInt(input);
                integerList.add(value);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer or 'done'.");
            }
        }
        int sum = 0;
        for (Integer num : integerList) {
            sum += num;
        }
        System.out.println("The sum of the entered integers is: " + sum);
        scanner.close();
    }
}
